## Description

<!-- Please write a description of your PR -->

## Checklist
<!-- Please confirm with `x` -->
- [ ] I've read [CONTRIBUTING.org](https://github.com/conao3/leaf.el/blob/master/CONTRIBUTING.org).
  - [ ] I've assign FSF.
  - [ ] The leaf.el after my changed pass all testcases by `make test`.
  - [ ] My changed elisp code byte-compiled cleanly.
  - [ ] I've added testcases related to my PR.
  - [ ] I've fixed README related the my added testcases.
